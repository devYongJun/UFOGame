﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Result : MonoBehaviour
{
    public GameObject inputBoard;
    public GameObject rankBoard;

    private void Start()
    {
        inputBoard.SetActive(true);
        rankBoard.SetActive(false);
    }

    public void OnButtonOK()
    {
        inputBoard.SetActive(false);
        rankBoard.SetActive(true);
    }

    public void OnButtonLobby()
    {
        SceneManager.LoadScene("LobbyScene");
    }

    public void OnButtonRestart()
    {
        SceneManager.LoadScene("PlayScene");
    }
}
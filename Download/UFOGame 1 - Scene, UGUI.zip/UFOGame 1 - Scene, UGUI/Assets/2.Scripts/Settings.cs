﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Settings : MonoBehaviour
{
    public Slider bgmSlider;
    public Slider sfxSlider;

    private void Start()
    {
        bgmSlider.value = 1f;
        sfxSlider.value = 1f;
    }

    public void OnChangedBGMVolume()
    {
        Debug.Log(bgmSlider.value);
    }

    public void OnChangedSFXVolume()
    {
        Debug.Log(sfxSlider.value);
    }

    public void OnButtonBack()
    {
        SceneManager.UnloadSceneAsync("SettingScene");
    }
}
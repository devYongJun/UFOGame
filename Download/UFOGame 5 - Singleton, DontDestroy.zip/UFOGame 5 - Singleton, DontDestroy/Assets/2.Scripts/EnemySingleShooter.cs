﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySingleShooter : EnemyBase
{
    protected override void Fire()
    {
        Instantiate(bullet, bulletSpawn.position, bulletSpawn.rotation);
    }
}

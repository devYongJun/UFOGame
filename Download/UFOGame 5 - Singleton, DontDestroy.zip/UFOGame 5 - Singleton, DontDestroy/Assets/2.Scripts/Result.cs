﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Result : MonoBehaviour
{
    public GameObject inputBoard;
    public GameObject rankBoard;
    public Transform scrollContent;
    public InputField inputUserName;


    private void Start()
    {
        inputBoard.SetActive(true);
        rankBoard.SetActive(false);
    }

    public void OnButtonOK()
    { 
        if(string.IsNullOrEmpty(inputUserName.text))
        {
            return;
        }

        inputBoard.SetActive(false);
        rankBoard.SetActive(true);
    }

    public void OnButtonLobby()
    {
        SceneManager.LoadScene("LobbyScene");
    }

    public void OnButtonRestart()
    {
        SceneManager.LoadScene("PlayScene");
    }
}
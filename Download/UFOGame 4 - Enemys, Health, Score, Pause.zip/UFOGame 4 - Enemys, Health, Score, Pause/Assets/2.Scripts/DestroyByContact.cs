﻿using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class DestroyByContact : MonoBehaviour
{
    public GameObject explosion;
    public HealthBar healthBar;
    public int score;

    GameController _gameController = null;

    private void Awake()
    {
        GameObject gameControllerObj = GameObject.FindWithTag("GameController");
        if(gameControllerObj != null)
        {
            _gameController = gameControllerObj.GetComponent<GameController>();
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Boundary"))
        {
            return;
        }

        if (collision.CompareTag("Bullet"))
        {
            Destroy(collision.gameObject);
        }

        healthBar.Decrease();

        if (healthBar.healthCur == 0)
        {
            if (this.gameObject.CompareTag("Player"))
            {
                _gameController.Gameover();
            }
            else if (this.gameObject.CompareTag("Enemy"))
            {
                _gameController.AddScore(score);
            }
            Instantiate(explosion, transform.position, transform.rotation);
            Destroy(this.gameObject);
        }
    }
}
